<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Visiter extends Model
{
    //
}
