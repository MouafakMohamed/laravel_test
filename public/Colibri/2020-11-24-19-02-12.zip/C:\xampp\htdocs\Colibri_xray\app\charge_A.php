<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class charge_A extends Model
{
    //
}
