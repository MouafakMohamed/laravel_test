<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Club_Students extends Model
{
    //
}
