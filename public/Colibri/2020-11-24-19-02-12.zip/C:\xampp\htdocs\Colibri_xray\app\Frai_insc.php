<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Frai_insc extends Model
{
    //
}
