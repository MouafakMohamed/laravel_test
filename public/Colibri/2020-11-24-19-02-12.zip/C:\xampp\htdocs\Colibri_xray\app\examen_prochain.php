<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class examen_prochain extends Model
{
    //
}
