<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Student_image extends Model
{
    //
}
