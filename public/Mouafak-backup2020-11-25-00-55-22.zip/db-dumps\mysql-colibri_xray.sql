
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `absences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `student` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `prof` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `etat` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `heure` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `heure1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `jour` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `absences` DISABLE KEYS */;
INSERT INTO `absences` (`id`, `class`, `student`, `prof`, `etat`, `heure`, `heure1`, `date`, `jour`, `desc`, `created_at`, `updated_at`) VALUES (18,'1','1','6','absence','14h30','19h30','2020-11-11','mardi',NULL,'2020-11-11 01:02:30','2020-11-11 01:02:30');
/*!40000 ALTER TABLE `absences` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `annances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `club` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `annances` DISABLE KEYS */;
/*!40000 ALTER TABLE `annances` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `biblios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `matiere` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `add_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `biblios` DISABLE KEYS */;
/*!40000 ALTER TABLE `biblios` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES (9,'Préscolaire','2020-10-07 19:20:27','2020-10-07 19:20:27'),(10,'Primaire','2020-10-07 19:20:27','2020-10-07 19:20:27'),(11,'Collège','2020-10-07 19:20:27','2020-10-07 19:20:27'),(12,'Lycée','2020-10-07 19:20:28','2020-10-07 19:20:28');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charge__a_s` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `prix` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `charge__a_s` DISABLE KEYS */;
INSERT INTO `charge__a_s` (`id`, `name`, `prix`, `created_at`, `updated_at`) VALUES (3,'colibri','1000','2020-10-22 19:52:29','2020-10-22 19:52:29');
/*!40000 ALTER TABLE `charge__a_s` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charges` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `categorie` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `prix` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `charges` DISABLE KEYS */;
INSERT INTO `charges` (`id`, `name`, `categorie`, `image`, `prix`, `date`, `created_at`, `updated_at`) VALUES (4,'colibri','annuelle','','1000','2020-10-01','2020-10-22 19:52:36','2020-10-22 19:52:36');
/*!40000 ALTER TABLE `charges` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `categorie` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cycle_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `classes_cycle_id_foreign` (`cycle_id`),
  CONSTRAINT `classes_cycle_id_foreign` FOREIGN KEY (`cycle_id`) REFERENCES `cycles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `classes` DISABLE KEYS */;
INSERT INTO `classes` (`id`, `name`, `categorie`, `cycle_id`, `created_at`, `updated_at`) VALUES (1,'classe 2','9',66,'2020-10-07 21:44:14','2020-10-07 22:14:29'),(2,'classe 1','9',66,'2020-10-07 22:14:07','2020-10-07 22:14:23'),(3,'Moyenne class 1','9',67,'2020-10-12 17:11:36','2020-10-12 17:11:55');
/*!40000 ALTER TABLE `classes` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club__students` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `club` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `student` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `validate` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `club__students` DISABLE KEYS */;
/*!40000 ALTER TABLE `club__students` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clubs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `prof` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `clubs` DISABLE KEYS */;
INSERT INTO `clubs` (`id`, `name`, `prof`, `image`, `created_at`, `updated_at`) VALUES (1,'théatre','6','images/students/16034047021.jpg','2020-10-22 22:11:42','2020-11-08 13:33:27');
/*!40000 ALTER TABLE `clubs` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commandes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pro` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fonction` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `staff` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `quantité` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `commandes` DISABLE KEYS */;
INSERT INTO `commandes` (`id`, `pro`, `fonction`, `staff`, `quantité`, `created_at`, `updated_at`) VALUES (1,'1','administration','18','10','2020-10-16 16:06:38','2020-10-16 16:06:38'),(2,'type1','administration','18','10','2020-10-16 16:51:01','2020-10-16 16:51:01'),(3,'type1','administration','23','22','2020-10-16 16:51:10','2020-10-16 16:51:10'),(4,'type1','administration','23','2','2020-10-16 16:51:19','2020-10-16 16:51:19'),(5,'type1','Professeur','5','10','2020-10-16 16:52:01','2020-10-16 16:52:01');
/*!40000 ALTER TABLE `commandes` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commentaires` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `student` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `commentaires` DISABLE KEYS */;
/*!40000 ALTER TABLE `commentaires` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tele` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adress` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cours` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `s_titre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `video` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cycle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `categorie` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `matiere` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `cours` DISABLE KEYS */;
INSERT INTO `cours` (`id`, `titre`, `s_titre`, `video`, `cycle`, `categorie`, `matiere`, `created_at`, `updated_at`) VALUES (1,'salam','salam','DlOO-EkdTCM','66','9','1','2020-10-09 20:47:04','2020-10-12 16:55:49'),(2,'salam','salam salam salam salam salam','kckQoKlSrA0','66','9','1','2020-10-19 13:56:00','2020-10-19 13:56:00');
/*!40000 ALTER TABLE `cours` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cycles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `categorie` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `cycles` DISABLE KEYS */;
INSERT INTO `cycles` (`id`, `name`, `categorie`, `created_at`, `updated_at`) VALUES (66,'Petite section','9','2020-10-07 19:20:27','2020-10-07 19:20:27'),(67,'Moyenne section','9','2020-10-07 19:20:27','2020-10-07 19:20:27'),(68,'Grande section','9','2020-10-07 19:20:27','2020-10-07 19:20:27'),(69,'CP','10','2020-10-07 19:20:27','2020-10-07 19:20:27'),(70,'CE1','10','2020-10-07 19:20:27','2020-10-07 19:20:27'),(71,'CE2','10','2020-10-07 19:20:27','2020-10-07 19:20:27'),(72,'CM1','10','2020-10-07 19:20:27','2020-10-07 19:20:27'),(73,'CM2','10','2020-10-07 19:20:27','2020-10-07 19:20:27'),(74,'CE6','10','2020-10-07 19:20:27','2020-10-07 19:20:27'),(75,'1ére Collége','11','2020-10-07 19:20:27','2020-10-07 19:20:27'),(76,'2éme Collége','11','2020-10-07 19:20:27','2020-10-07 19:20:27'),(77,'3éme Collége','11','2020-10-07 19:20:27','2020-10-07 19:20:27'),(78,'T.C','12','2020-10-07 19:20:28','2020-10-07 19:20:28'),(79,'1ére BAC','12','2020-10-07 19:20:28','2020-10-07 19:20:28'),(80,'2éme BAC','12','2020-10-07 19:20:28','2020-10-07 19:20:28');
/*!40000 ALTER TABLE `cycles` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devoires` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `matiere` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `devoires` DISABLE KEYS */;
INSERT INTO `devoires` (`id`, `class`, `matiere`, `date1`, `date2`, `desc`, `image`, `created_at`, `updated_at`) VALUES (2,'1','1','2020-10-18','2020-10-23','walo akhay rire tka m3a rask','','2020-10-18 14:57:45','2020-10-18 14:57:45'),(3,'1','1','2020-10-18','2020-10-23','walo','images/devoires/1603033467.jpg','2020-10-18 15:04:27','2020-10-18 15:04:27');
/*!40000 ALTER TABLE `devoires` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emplois` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `matiere` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `salle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `heur` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `jour` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `emplois` DISABLE KEYS */;
INSERT INTO `emplois` (`id`, `class`, `matiere`, `salle`, `heur`, `jour`, `created_at`, `updated_at`) VALUES (26,'1','1','2','8h30','lundi','2020-11-09 21:11:41','2020-11-09 21:11:41'),(27,'1','1','2','9h30','lundi','2020-11-09 21:11:52','2020-11-09 21:11:52'),(28,'1','2','2','10h30','lundi','2020-11-09 21:28:12','2020-11-09 21:28:12'),(29,'1','2','2','11h30','lundi','2020-11-09 21:28:19','2020-11-09 21:28:19'),(32,'1','1','2','8h30','mardi','2020-11-10 17:05:08','2020-11-10 17:05:08'),(33,'1','1','2','9h30','mardi','2020-11-10 17:05:14','2020-11-10 17:05:14'),(35,'1','1','2','14h30','mardi','2020-11-10 21:19:14','2020-11-10 21:19:14'),(40,'1','1','2','11h30','mardi','2020-11-10 23:26:02','2020-11-10 23:26:02'),(42,'1','1','2','12h30','mardi','2020-11-10 23:52:11','2020-11-10 23:52:11'),(43,'1','1','2','15h30','mardi','2020-11-10 23:55:54','2020-11-10 23:55:54'),(44,'1','1','2','16h30','mardi','2020-11-10 23:56:05','2020-11-10 23:56:05'),(45,'1','1','2','17h30','mardi','2020-11-10 23:56:11','2020-11-10 23:56:11'),(46,'1','1','2','18h30','mardi','2020-11-10 23:56:17','2020-11-10 23:56:17'),(47,'1','1','2','10h30','mardi','2020-11-10 23:56:50','2020-11-10 23:56:50'),(48,'2','1','2','16h30','mercredi','2020-11-11 15:32:25','2020-11-11 15:32:25');
/*!40000 ALTER TABLE `emplois` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_classes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `exam` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `matiere` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `exam_classes` DISABLE KEYS */;
INSERT INTO `exam_classes` (`id`, `class`, `exam`, `matiere`, `created_at`, `updated_at`) VALUES (14,'2','32','arabic','2020-11-06 02:11:33','2020-11-06 02:11:33'),(24,'1','34','arabic','2020-11-06 13:27:22','2020-11-06 13:27:22'),(25,'2','34','arabic','2020-11-06 13:27:22','2020-11-06 13:27:22');
/*!40000 ALTER TABLE `exam_classes` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `examen_prochains` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `matiere` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `reated_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `desc` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `examen_prochains` DISABLE KEYS */;
/*!40000 ALTER TABLE `examen_prochains` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `examens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `desc` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `fichier` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prof` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `examens` DISABLE KEYS */;
INSERT INTO `examens` (`id`, `name`, `desc`, `fichier`, `prof`, `created_at`, `updated_at`) VALUES (32,'test','test','exams/16046272651.jpg','6','2020-11-06 01:47:45','2020-11-06 01:47:45'),(34,'exam arabic','ok it\'s done','exams/16046692421.jpg','6','2020-11-06 13:27:22','2020-11-06 13:27:22');
/*!40000 ALTER TABLE `examens` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8_unicode_ci NOT NULL,
  `queue` text COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `prof_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `files_user_id_foreign` (`user_id`),
  KEY `files_prof_id_foreign` (`prof_id`),
  CONSTRAINT `files_prof_id_foreign` FOREIGN KEY (`prof_id`) REFERENCES `profs` (`id`),
  CONSTRAINT `files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `staff` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `frai_inscs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student` int(11) NOT NULL,
  `frais_insc` int(11) NOT NULL,
  `Transport` int(11) NOT NULL,
  `Cantine` int(11) NOT NULL,
  `Guarde` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `frai_inscs` DISABLE KEYS */;
INSERT INTO `frai_inscs` (`id`, `student`, `frais_insc`, `Transport`, `Cantine`, `Guarde`, `created_at`, `updated_at`) VALUES (5,1,1200,400,400,50,'2020-11-17 21:59:40','2020-11-17 21:59:40'),(6,7,1200,400,400,50,'2020-11-18 11:32:07','2020-11-18 11:32:07'),(7,8,1200,400,400,50,'2020-11-18 11:34:16','2020-11-18 11:34:16');
/*!40000 ALTER TABLE `frai_inscs` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `frais` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `massar` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `prix` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `frais` DISABLE KEYS */;
INSERT INTO `frais` (`id`, `student`, `massar`, `date`, `prix`, `created_at`, `updated_at`) VALUES (61,'1','CS87432546','09-2020','1200','2020-11-17 22:22:37','2020-11-17 22:22:37'),(62,'1','CS87432546','10-2020','1200','2020-11-17 22:22:37','2020-11-17 22:22:37'),(63,'1','CS87432546','11-2020','1200','2020-11-17 22:22:37','2020-11-17 22:22:37');
/*!40000 ALTER TABLE `frais` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `friends` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `student2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `roll` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `friends` DISABLE KEYS */;
/*!40000 ALTER TABLE `friends` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `licences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `licence` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `licences` DISABLE KEYS */;
INSERT INTO `licences` (`id`, `licence`, `id_name`, `created_at`, `updated_at`) VALUES (1,'AZAMI','$2y$10$x.wvQPNcD1e9wSqkZBGaVeWKInwIW0Cbh.nO9rPmwbEJZx8I74bvC',NULL,NULL);
/*!40000 ALTER TABLE `licences` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matieres` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `matieres` DISABLE KEYS */;
INSERT INTO `matieres` (`id`, `name`, `created_at`, `updated_at`) VALUES (1,'arabic','2020-10-07 21:35:43','2020-10-07 22:18:42'),(2,'Francais','2020-11-09 21:12:38','2020-11-09 21:12:38');
/*!40000 ALTER TABLE `matieres` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2020_05_30_081612_create_staff_table',1),(5,'2020_05_31_071352_create_profs_table',1),(6,'2020_05_31_232100_create_files_table',1),(7,'2020_06_02_112005_create_licences_table',1),(8,'2020_06_06_015852_create_salle_models_table',1),(9,'2020_06_06_034723_create_cycles_table',1),(10,'2020_06_06_034932_create_matieres_table',1),(11,'2020_06_07_054936_create_transports_table',1),(12,'2020_06_07_144706_create_trajets_table',1),(13,'2020_06_08_063135_create_classes_table',1),(14,'2020_06_09_080039_create_emplois_table',1),(15,'2020_06_09_133342_create_students_table',1),(16,'2020_06_11_091924_create_student_files_table',1),(17,'2020_06_11_123828_create_timelines_table',1),(18,'2020_06_12_110841_create_parents_table',1),(19,'2020_06_12_161025_create_devoires_table',1),(20,'2020_06_13_105717_create_biblios_table',1),(21,'2020_06_14_094640_create_cours_table',1),(22,'2020_06_14_145153_create_parent_students_table',1),(23,'2020_06_15_085700_create_friends_table',1),(24,'2020_06_17_122226_create_student_images_table',1),(25,'2020_06_22_154713_create_produits_table',1),(26,'2020_06_30_180158_create_frais_table',1),(27,'2020_07_24_175725_create_table_pros_table',1),(28,'2020_07_25_155343_create_commandes_table',1),(29,'2020_07_26_032343_create_salaires_table',1),(30,'2020_07_27_191217_create_charges_table',1),(31,'2020_08_03_141301_create_visiters_table',1),(32,'2020_08_03_145717_create_contacts_table',1),(33,'2020_08_04_185409_create_clubs_table',1),(34,'2020_08_05_182456_create_club__students_table',1),(35,'2020_08_07_190948_create_prof_classes_table',1),(36,'2020_08_08_234313_create_examens_table',1),(37,'2020_08_10_004143_create_notes_table',1),(38,'2020_08_10_231836_create_annances_table',1),(39,'2020_08_13_180618_create_categories_table',1),(40,'2020_08_21_024615_create_absences_table',1),(41,'2020_08_30_002141_create_tracabilites_table',1),(42,'2020_10_05_200422_create_prixes_table',1),(44,'2020_10_19_155207_create_commentaires_table',2),(45,'2020_10_22_153445_create_charge__a_s_table',3),(46,'2020_11_03_142503_create_examen_prochains_table',4),(47,'2020_11_06_020113_create_exam_classes_table',5),(48,'2020_11_17_214404_create_frai_inscs_table',6);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `exam` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `eleve` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `prof` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` (`id`, `exam`, `note`, `eleve`, `class`, `prof`, `created_at`, `updated_at`) VALUES (15,'32','20','1','2','6','2020-11-06 19:33:12','2020-11-06 19:34:20'),(16,'34','12','1','1','6','2020-11-07 18:50:07','2020-11-07 18:50:07'),(17,'32','15','3','2','6','2020-11-08 13:14:28','2020-11-08 13:31:17'),(18,'32','16','4','2','6','2020-11-08 13:14:33','2020-11-16 17:54:12'),(19,'34','10','5','1','6','2020-11-16 17:54:25','2020-11-16 17:54:25'),(20,'34','10','2','1','6','2020-11-16 17:54:27','2020-11-16 17:54:27');
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parent_students` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `student` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tuteur` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `relation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `parent_students` DISABLE KEYS */;
INSERT INTO `parent_students` (`id`, `parent`, `student`, `tuteur`, `relation`, `created_at`, `updated_at`) VALUES (4,'1','1','oui',NULL,'2020-10-08 01:28:44','2020-10-08 01:28:55');
/*!40000 ALTER TABLE `parent_students` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nom` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cin` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sex` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tele` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `adress` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `insta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `parents` DISABLE KEYS */;
INSERT INTO `parents` (`id`, `image`, `nom`, `pre`, `cin`, `sex`, `mail`, `tele`, `adress`, `facebook`, `twitter`, `insta`, `youtube`, `user`, `password`, `created_at`, `updated_at`) VALUES (1,'images/students/1602154915.jfif','madam','madam','31548711111','Femme','test5214@test.test','2153269854','adress',NULL,NULL,NULL,NULL,'test5214@test.test','$2y$10$HFOMnHXuxKkkEwlGP1iOTuY7fBwAWjEZ.DYwfUZfaSWn6yvNf286O','2020-10-08 01:14:44','2020-10-08 11:01:55');
/*!40000 ALTER TABLE `parents` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prixes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `m09` int(11) DEFAULT NULL,
  `m10` int(11) DEFAULT NULL,
  `m11` int(11) DEFAULT NULL,
  `m12` int(11) DEFAULT NULL,
  `m01` int(11) DEFAULT NULL,
  `m02` int(11) DEFAULT NULL,
  `m03` int(11) DEFAULT NULL,
  `m04` int(11) DEFAULT NULL,
  `m05` int(11) DEFAULT NULL,
  `m06` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `prixes` DISABLE KEYS */;
INSERT INTO `prixes` (`id`, `student`, `m09`, `m10`, `m11`, `m12`, `m01`, `m02`, `m03`, `m04`, `m05`, `m06`, `created_at`, `updated_at`) VALUES (1,'1',1200,1200,1200,1200,1200,1200,1200,1200,1200,1200,'2020-10-07 22:46:04','2020-11-17 21:59:40'),(2,'2',1200,1200,1200,1200,1200,1200,1200,1200,1200,1200,'2020-10-11 13:10:39','2020-11-17 21:34:08'),(3,'3',1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,'2020-10-11 13:32:12','2020-11-17 21:44:34'),(4,'4',NULL,600,600,600,600,600,600,600,600,600,'2020-10-11 23:08:50','2020-11-17 21:11:43'),(5,'5',NULL,NULL,1200,1200,1200,1200,1200,1200,1200,1200,'2020-11-12 18:01:56','2020-11-12 18:01:56'),(6,'7',NULL,NULL,1000,1000,1000,1000,1000,1000,1000,1000,'2020-11-18 11:32:07','2020-11-18 11:32:07'),(7,'8',1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,'2020-11-18 11:34:16','2020-11-18 11:34:16');
/*!40000 ALTER TABLE `prixes` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ref` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `quantité` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `prix` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `min` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `produits` DISABLE KEYS */;
INSERT INTO `produits` (`id`, `name`, `ref`, `quantité`, `prix`, `min`, `image`, `created_at`, `updated_at`) VALUES (1,'type1','fgh','36','50','5','images/produit.jpg','2020-10-16 15:56:01','2020-10-16 16:52:01');
/*!40000 ALTER TABLE `produits` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prof_classes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `matiere` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `prof` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `prof_classes` DISABLE KEYS */;
INSERT INTO `prof_classes` (`id`, `class`, `matiere`, `prof`, `created_at`, `updated_at`) VALUES (3,'1','1','6','2020-10-12 15:07:50','2020-10-12 15:07:50'),(5,'3','1','6','2020-11-06 01:45:54','2020-11-06 01:45:54'),(6,'2','1','6','2020-11-10 17:17:27','2020-11-10 17:17:27');
/*!40000 ALTER TABLE `prof_classes` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cin` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tele` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sex` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fonction` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `post` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `salaire` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `compet` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rib` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `banque` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cnss` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `facebook` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `insta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `linked` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `block` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `profs_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `profs` DISABLE KEYS */;
INSERT INTO `profs` (`id`, `nom`, `pre`, `image`, `cin`, `tele`, `sex`, `date`, `adress`, `fonction`, `post`, `type`, `type1`, `date1`, `date2`, `salaire`, `compet`, `rib`, `banque`, `cnss`, `status`, `email`, `facebook`, `twitter`, `insta`, `linked`, `block`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES (5,'khokha','mouafak','images/femme.png','c1111111118','215411111118','Femme','2020-10-07','test','Professeur','rien','CDI','mois','2020-10-01',NULL,'6000','ok','32165498731654987','banque populaire','32165498731654987','Célibataire','test02101@001.ma8',NULL,NULL,NULL,NULL,NULL,NULL,'$2y$10$ZvpQ.ZBJOYDFR.AkC8R0Few9mDExHPHwUnrPua5WzT2uOVAZ7Xwdi',NULL,'2020-10-08 17:22:05','2020-10-08 17:22:05'),(6,'Colibri','system','images/homme.jpg','c11111111','0505050505','Homme','2020-10-01','rien','Professeur','rien','CDI','mois','2020-10-01',NULL,'3000','walo','32165498731654987','banque populaire','32165498731654987','Célibataire','salam_teste@salam.com',NULL,NULL,NULL,NULL,NULL,NULL,'$2y$10$DQuFQDvhRFC06TPZLw6Oy.JfMKBmvrlbGshCq6/CiOxKXT48sSHgC',NULL,'2020-10-10 22:33:50','2020-10-10 22:33:50');
/*!40000 ALTER TABLE `profs` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salaires` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `staff` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `prof` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `salaire` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `salaires` DISABLE KEYS */;
INSERT INTO `salaires` (`id`, `staff`, `prof`, `salaire`, `date`, `created_at`, `updated_at`) VALUES (1,'18','rien','6000','09-2020','2020-10-08 01:35:55','2020-10-08 01:35:55');
/*!40000 ALTER TABLE `salaires` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salle_models` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `salle_models_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `salle_models` DISABLE KEYS */;
INSERT INTO `salle_models` (`id`, `name`, `created_at`, `updated_at`) VALUES (2,'salle 1','2020-10-07 21:25:55','2020-10-07 22:18:36');
/*!40000 ALTER TABLE `salle_models` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cin` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tele` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sex` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fonction` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `post` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `post_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `salaire` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `compet` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rib` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `banque` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cnss` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `transport` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emploi` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `basedonne` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GRH` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `biblio` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cours` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `livre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contacts` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `clubs` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stock` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `facebook` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `insta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `linked` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `block` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `staff_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` (`id`, `nom`, `pre`, `image`, `cin`, `tele`, `sex`, `date`, `adress`, `fonction`, `post`, `post_name`, `type`, `date1`, `date2`, `salaire`, `compet`, `rib`, `banque`, `cnss`, `status`, `class`, `transport`, `emploi`, `basedonne`, `GRH`, `biblio`, `cours`, `livre`, `contacts`, `clubs`, `stock`, `email`, `facebook`, `twitter`, `insta`, `linked`, `block`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES (18,'mouafak','mohamed','images/users/16021068631.jpg','cd1990181','2154854215781','Homme','2020-10-08','adress1','Administration','secritére','directeur','CDI','2020-09-08',NULL,'6000','rien walo','3216549873rien','banque populaire','3216549873165rientous','Célibataire',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'mouafak@mouafak.com1',NULL,NULL,NULL,NULL,NULL,NULL,'$2y$10$geKGjtZznxYmK0yzX9V.sOPBvb0u11egoM9CNEJU8/xvHMkKust52',NULL,'2020-10-07 21:39:57','2020-10-07 21:42:11'),(19,'salim','mohamed','images/users/16021092481.jpg','c215498','0251487458','Homme','2020-10-07','salam','Staff','Chauffeur','rien','CDI','2020-10-15',NULL,'3000','test','32165498731654987','banque populaire','32165498731654987','Célibataire',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'salam@salam.com',NULL,NULL,NULL,NULL,NULL,NULL,'$2y$10$xx.0j7/rNaZ6KT2.dcEc0uHcSbi8wKI6Mb4YMZpHl4iI328eS0o5O',NULL,'2020-10-07 22:20:48','2020-10-07 22:20:48'),(20,'khokha','khokha','images/femme.png','cd908','2154878547','Femme','2020-10-08','kjhgtyj','Staff','Accompagnement','rien','CDI','2020-10-22',NULL,'2499','test','32165498731654987','cih','32165498731654987','Marié(e)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'mouafak@mail.com',NULL,NULL,NULL,NULL,NULL,NULL,'$2y$10$c.wtmJWUYmoJeF2fT.JItuz74FDsNfN56VXQEoKRCCXGDq3u3ZWdC',NULL,'2020-10-07 22:22:08','2020-10-07 22:22:08'),(21,'khokha','khokha','images/homme.jpg','cd9081','21548785471','Homme','2020-10-08','kjhgtyj','Staff','Sécurité','rien','CDI','2020-10-22',NULL,'2500','test','32165498731654987','cih','32165498731654987','Célibataire',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'mouafak@mail.com11',NULL,NULL,NULL,NULL,NULL,NULL,'$2y$10$lTg./bssJWyvhkovLJg4OeMJrW2V.kP/q8x2a5IbsMW/Gi.MJVYOW',NULL,'2020-10-07 22:29:12','2020-10-07 22:29:12'),(22,'walo','walo','images/homme.jpg','cd 199908','215485421578111','Homme','2020-10-06','walo','Administration','secrétaire','rien','CDI','2020-10-01',NULL,'3000','rien','32165498731654987','banque populaire','32165498731654987','Fiancé(e)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'salam111@salam.com',NULL,NULL,NULL,NULL,NULL,NULL,'$2y$10$ycAnUsilKfPFm3q4WuR9xe9yYHpltn1Mpn7Cy74ffRhJm2RlWLDni',NULL,'2020-10-08 10:54:47','2020-10-08 10:54:47'),(23,'khokha','khokha','images/femme.png','cd 1999082222','2154854215782222','Femme','2020-10-10','test','Administration','secrétaire','rien','CDI','2020-10-02',NULL,'2999','test','32165498731654987','banque populaire','3216549873165rientous','Célibataire','rien',NULL,NULL,NULL,'rien',NULL,NULL,NULL,NULL,NULL,NULL,'tes3215t@001.ma',NULL,NULL,NULL,NULL,NULL,NULL,'$2y$10$C0iS2qDvzhRbjMprV6uOmePVu4Alg2T/21vQeeHTGmNSE0SwuI48y',NULL,'2020-10-08 17:23:45','2020-11-10 15:49:53'),(24,'salim','mohamed','images/homme.jpg','c199908','215485421578','Homme','2020-10-01','test','Administration','secrétaire','rien','CDI','2020-10-22',NULL,'5000','oki','32165498731654987','banque populaire','32165498731654987','Célibataire',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'salamtest@salam.com',NULL,NULL,NULL,NULL,NULL,NULL,'$2y$10$ubjKZwKuNRaqv3hV.WBeB.Is9QxGXNqOOkjEN9LiIP12P7jbOirm.',NULL,'2020-10-10 22:20:14','2020-10-10 22:20:14');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `student_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `student_files` DISABLE KEYS */;
INSERT INTO `student_files` (`id`, `name`, `image`, `student_id`, `created_at`, `updated_at`) VALUES (3,'salle 1','images/files/16021177001.png','1','2020-10-08 00:41:40','2020-10-08 00:41:40');
/*!40000 ALTER TABLE `student_files` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `student_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `student_images` DISABLE KEYS */;
INSERT INTO `student_images` (`id`, `image`, `student_id`, `created_at`, `updated_at`) VALUES (1,'images/student_images/1602118443.jpg','1','2020-10-08 00:54:03','2020-10-08 00:54:03'),(2,'images/student_images/1602120610.jpg','1','2020-10-08 01:30:10','2020-10-08 01:30:10');
/*!40000 ALTER TABLE `student_images` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nom1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pre1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sex` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `incsription_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `adress` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `payement` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `image_qr` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `categorie` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cycle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `class_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_d` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `transport` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trajet` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `insta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fich` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `med_nom` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `med_tel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `med_adress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `anne` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passe` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `height` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weight` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blood` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` (`id`, `id1`, `nom`, `pre`, `nom1`, `pre1`, `sex`, `incsription_num`, `date`, `adress`, `payement`, `image_qr`, `image`, `categorie`, `cycle`, `class`, `class_num`, `date_d`, `transport`, `trajet`, `facebook`, `twitter`, `insta`, `youtube`, `fich`, `med_nom`, `med_tel`, `med_adress`, `anne`, `passe`, `height`, `weight`, `blood`, `user`, `password`, `created_at`, `updated_at`) VALUES (1,'CS87432546','salma','salma','salma','salma','Garçon','5126548dgdfg','2020-10-07','115 alot 3 rout meknes wed fes fes','rien',NULL,'images/students/16058175991.jpg','9','66',NULL,'','2020-09-01','','',NULL,NULL,NULL,NULL,'slam cv ???\r\ncv hmd toi cv ???\r\ncv hmd lhla ykhtik','mohamed','abdelilah','driss','2020/2021','non','1.10','50','B+','CS87432546','$2y$10$DDvr9KIo0VT9ePQFIRahv.Z5IUfP2aT0M1ClnhjdFHSjgPijNTxSy','2020-10-07 22:46:04','2020-11-19 20:26:39'),(2,'CS84506917','student','student','student','student','Garçon','2415784','2020-10-01','115 alot 3 rout meknes wed fes fes','rien',NULL,'images/students/garcon.jpg','9','66',NULL,'','2020-09-16','','',NULL,NULL,NULL,NULL,'walo1',NULL,NULL,NULL,'',NULL,'1.10','50','AB-','CS84506917','$2y$10$LMmiAwNc3bUmcPvLglVf0ebfoGVbvifa61xozbl6wZpoXQn6M6mPa','2020-10-11 13:10:38','2020-11-17 21:31:21'),(3,'CS50315366','mohamed','azami','العلوي','محمد','Garçon','512','2020-10-01','115 alot 3 rout meknes wed fes fes','rien',NULL,'images/students/fille.jpg','9','66',NULL,'','2020-09-01','','',NULL,NULL,NULL,NULL,'walo had sa3a','man3raaaft akhay','0606060606','adress 1','',NULL,'1.50','50','AB-','CS50315366','$2y$10$H7ho4PFOmfd5I6XPJTVqX.FaJ5OLEBc9jXff3Vfgu1Hz5zDvUqQ0i','2020-10-11 13:32:11','2020-11-17 21:51:07'),(4,'CS11278762','khokha','mouafak','العلوي','محمد','Garçon',NULL,'2020-10-08','115 alot 3 rout meknes wed fes fes','rien',NULL,'images/students/garcon.jpg','9','66','2','2','2020-10-01','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'CS11278762','$2y$10$7ey5u/vxbnvO0vSxNkP8NeICg1rItXyDyoI2ozTn7wiDBpAnZM7LG','2020-10-11 23:08:50','2020-11-06 17:01:22'),(5,'CS45989720','islam','islam','islam','islam','Garçon','5126548','2020-11-11','115 alot 3 rout meknes wed fes fes 111 115 alot 3 rout meknes wed fe','mois',NULL,'images/students/garcon.jpg','9','66','1',NULL,'2020-11-12','1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'CS45989720','$2y$10$mk5VKYr85YaX6sTlYVQu1.jnJLMGjW9Wc5sOFPLYdnwo.6CsIqeCC','2020-11-12 18:01:56','2020-11-12 19:18:40'),(8,'CS52122196','ahlan','ostad','ostad','ostad','Garçon','32165487','2020-10-27','115 alot 3 rout meknes wed fes fes','mois',NULL,'images/students/garcon.jpg','9','66','1',NULL,'2020-09-11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020/2021',NULL,NULL,NULL,NULL,'CS52122196','$2y$10$SyiL2ZtC2oPrTt8.0SXsaOAiWcksk8xToV6JBV7thtlD5QRIh1aIK','2020-11-18 11:34:16','2020-11-18 11:34:16');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `table_pros` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ref` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `quantité` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `prix` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `table_pros` DISABLE KEYS */;
INSERT INTO `table_pros` (`id`, `name`, `ref`, `quantité`, `prix`, `date`, `user`, `created_at`, `updated_at`) VALUES (1,'4','fgh','100','50','16/10/2020','admin','2020-10-16 16:00:52','2020-10-16 16:00:52'),(2,'5','dfgdfg','50','50','16/10/2020','admin','2020-10-16 16:25:13','2020-10-16 16:25:13');
/*!40000 ALTER TABLE `table_pros` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timelines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sujet` text COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `student_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `timelines` DISABLE KEYS */;
INSERT INTO `timelines` (`id`, `name`, `date`, `sujet`, `image`, `student_id`, `by`, `created_at`, `updated_at`) VALUES (1,'admin','08/10/2020','walo akhay simo','images/files/16021174471.png','1','2','2020-10-08 00:37:27','2020-10-08 00:37:27'),(2,'admin','13/10/2020','slem 3lik lm3alam','','2','2','2020-10-13 01:04:40','2020-10-13 01:04:40'),(3,'admin','13/10/2020','salam','','3','2','2020-10-13 01:06:17','2020-10-13 01:06:17'),(4,'admin','21/10/2020','had bnadem mriiiid','','1','2','2020-10-21 00:43:56','2020-10-21 00:43:56'),(5,'admin','08/11/2020','test','','1','2','2020-11-08 18:23:34','2020-11-08 18:23:34'),(6,'parent','09/11/2020','salam','','1','1','2020-11-09 01:35:50','2020-11-09 01:35:50'),(7,'parent','09/11/2020','khouya simo','images/files/16048862691.PNG','1','1','2020-11-09 01:44:29','2020-11-09 01:44:29'),(8,'prof','09/11/2020','just a test','images/files/16049284951.PNG','3','6','2020-11-09 13:28:15','2020-11-09 13:28:15'),(9,'prof','09/11/2020','salam khouya simo cv ??','','1','6','2020-11-09 13:30:12','2020-11-09 13:30:12');
/*!40000 ALTER TABLE `timelines` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tracabilites` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `genre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=291 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `tracabilites` DISABLE KEYS */;
INSERT INTO `tracabilites` (`id`, `name`, `genre`, `text`, `created_at`, `updated_at`) VALUES (1,'Admin','ajouter',' a ajouter une nouvelle categorie \"mouafak\"','2020-10-07 21:13:10','2020-10-07 21:13:10'),(2,'Admin','ajouter',' a ajouter un nouveau cycle \"mouafak\"','2020-10-07 21:13:33','2020-10-07 21:13:33'),(3,'Admin','modifier',' a modifier les informations de le cycle \"mouafak\"','2020-10-07 21:24:27','2020-10-07 21:24:27'),(4,'Admin','modifier',' a modifier les informations de le cycle \"mouafak\"','2020-10-07 21:25:06','2020-10-07 21:25:06'),(5,'Admin','modifier',' a modifier les informations de le cycle \"mouafak\"','2020-10-07 21:25:16','2020-10-07 21:25:16'),(6,'Admin','delete',' a supprimer le cycle \"mouafak\"','2020-10-07 21:25:22','2020-10-07 21:25:22'),(7,'Admin','delete',' a supprimer la catégorie \"mouafak\"','2020-10-07 21:25:27','2020-10-07 21:25:27'),(8,'Admin','ajouter',' a ajouter une nouveau salle \"salle 1\"','2020-10-07 21:25:38','2020-10-07 21:25:38'),(9,'Admin','ajouter',' a modifier le nom de la salle \"salle 12\"','2020-10-07 21:25:45','2020-10-07 21:25:45'),(10,'Admin','delete',' a supprimer la salle \"salle 12\"','2020-10-07 21:25:49','2020-10-07 21:25:49'),(11,'Admin','ajouter',' a ajouter une nouveau salle \"salle 1\"','2020-10-07 21:25:55','2020-10-07 21:25:55'),(12,'Admin','ajouter',' a modifier le nom de la salle \"salle 1\"','2020-10-07 21:35:24','2020-10-07 21:35:24'),(13,'Admin','ajouter',' a ajouter une nouveau matiere \"arabic\"','2020-10-07 21:35:43','2020-10-07 21:35:43'),(14,'Admin','modifier',' a modifier les informations de \"mouafak mohamed\"','2020-10-07 21:41:03','2020-10-07 21:41:03'),(15,'Admin','modifier',' a modifier les informations de \"mouafak mohamed\"','2020-10-07 21:41:27','2020-10-07 21:41:27'),(16,'Admin','modifier',' a modifier les informations de \"mouafak mohamed\"','2020-10-07 21:41:50','2020-10-07 21:41:50'),(17,'Admin','modifier',' a modifier les informations de \"mouafak mohamed\"','2020-10-07 21:42:11','2020-10-07 21:42:11'),(18,'Admin','ajouter',' a ajouter une nouveau fichier sur le compte de \"mouafak mohamed\"','2020-10-07 21:42:33','2020-10-07 21:42:33'),(19,'Admin','delete',' a supprimer une fichier sur le compte de \"mouafak mohamed\"','2020-10-07 21:43:03','2020-10-07 21:43:03'),(20,'Admin','ajouter',' a ajouter une nouveau fichier sur le compte de \"mouafak mohamed\"','2020-10-07 21:43:29','2020-10-07 21:43:29'),(21,'Admin','delete',' a supprimer une fichier sur le compte de \"mouafak mohamed\"','2020-10-07 21:43:36','2020-10-07 21:43:36'),(22,'Admin','ajouter',' a ajouter une nouveau class \"classe 1\"','2020-10-07 21:44:14','2020-10-07 21:44:14'),(23,'Admin','ajouter',' a ajouter une nouveau class \"classe 2\"','2020-10-07 22:14:08','2020-10-07 22:14:08'),(24,'Admin','ajouter',' a modifier les informations de la class \"classe 3\"','2020-10-07 22:14:16','2020-10-07 22:14:16'),(25,'Admin','ajouter',' a modifier les informations de la class \"classe 1\"','2020-10-07 22:14:23','2020-10-07 22:14:23'),(26,'Admin','ajouter',' a modifier les informations de la class \"classe 2\"','2020-10-07 22:14:29','2020-10-07 22:14:29'),(27,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-07 22:17:08','2020-10-07 22:17:08'),(28,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-07 22:17:18','2020-10-07 22:17:18'),(29,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-07 22:17:23','2020-10-07 22:17:23'),(30,'Admin','ajouter',' a modifier le nom de la salle \"salle test\"','2020-10-07 22:18:04','2020-10-07 22:18:04'),(31,'Admin','modifier',' a modifier les informations de la matiére \"arabic test\"','2020-10-07 22:18:11','2020-10-07 22:18:11'),(32,'Admin','ajouter',' a modifier le nom de la salle \"salle 1\"','2020-10-07 22:18:36','2020-10-07 22:18:36'),(33,'Admin','modifier',' a modifier les informations de la matiére \"arabic\"','2020-10-07 22:18:42','2020-10-07 22:18:42'),(34,'Admin','ajouter',' a ajouter un nouveau transport \"trans 1\"','2020-10-07 22:33:32','2020-10-07 22:33:32'),(35,'Admin','ajouter',' a ajouter une nouveau éléve \"salma salma\"','2020-10-07 22:46:04','2020-10-07 22:46:04'),(36,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-07 22:46:29','2020-10-07 22:46:29'),(37,'Admin','modifier',' a modifier les informations de l\'éléve \"salma1 salma1\"','2020-10-07 22:47:04','2020-10-07 22:47:04'),(38,'Admin','modifier',' a modifier les informations de l\'éléve \"salma1 salma1\"','2020-10-07 22:51:19','2020-10-07 22:51:19'),(39,'Admin','modifier',' a modifier les informations de l\'éléve \"salma1 salma1\"','2020-10-07 22:51:31','2020-10-07 22:51:31'),(40,'Admin','modifier',' a modifier les informations de l\'éléve \"salma1 salma1\"','2020-10-07 22:51:38','2020-10-07 22:51:38'),(41,'Admin','modifier',' a modifier les informations de l\'éléve \"salma1 salma1\"','2020-10-07 22:52:10','2020-10-07 22:52:10'),(42,'Admin','modifier',' a modifier le prix de l\'éléve \"salma salma\"','2020-10-08 00:02:36','2020-10-08 00:02:36'),(43,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-08 00:27:17','2020-10-08 00:27:17'),(44,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-08 00:30:04','2020-10-08 00:30:04'),(45,'Admin','ajouter',' a ajouter une fichier sur le profil de l\'éléve \"salma salma\"','2020-10-08 00:33:25','2020-10-08 00:33:25'),(46,'Admin','delete',' a supprimer une fichier de \"salma salma\"','2020-10-08 00:33:38','2020-10-08 00:33:38'),(47,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-08 00:34:07','2020-10-08 00:34:07'),(48,'Admin','ajouter',' a ajouter une fichier sur le profil de l\'éléve \"salma salma\"','2020-10-08 00:35:04','2020-10-08 00:35:04'),(49,'Admin','delete',' a supprimer une fichier de \"salma salma\"','2020-10-08 00:35:12','2020-10-08 00:35:12'),(50,'Admin','ajouter',' a ajouter une commentaire sur le profil de l\'éléve \"salma salma\"','2020-10-08 00:37:27','2020-10-08 00:37:27'),(51,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-08 00:38:33','2020-10-08 00:38:33'),(52,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-08 00:40:25','2020-10-08 00:40:25'),(53,'Admin','ajouter',' a ajouter une fichier sur le profil de l\'éléve \"salma salma\"','2020-10-08 00:41:40','2020-10-08 00:41:40'),(54,'Admin','ajouter',' a ajouter un image pour \"salma salma\"','2020-10-08 00:54:03','2020-10-08 00:54:03'),(55,'Admin','modifier',' a modifier les informations de \"madam madam\"','2020-10-08 01:14:44','2020-10-08 01:14:44'),(56,'Admin','ajouter',' a ajouter un des parents sur le profil de l\'éléve \"salma salma\"','2020-10-08 01:19:31','2020-10-08 01:19:31'),(57,'Admin','ajouter',' a ajouter un des parents sur le profil de l\'éléve \"salma salma\"','2020-10-08 01:23:49','2020-10-08 01:23:49'),(58,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-08 01:27:32','2020-10-08 01:27:32'),(59,'Admin','ajouter',' a ajouter un des parents sur le profil de l\'éléve \"salma salma\"','2020-10-08 01:28:44','2020-10-08 01:28:44'),(60,'Admin','modifier',' a modifier le tuteur de \"salma salma\"','2020-10-08 01:28:55','2020-10-08 01:28:55'),(61,'Admin','ajouter',' a ajouter un image pour \"salma salma\"','2020-10-08 01:30:10','2020-10-08 01:30:10'),(62,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 10-2020','2020-10-08 01:31:25','2020-10-08 01:31:25'),(63,'Admin','salaire',' a valider le salaire de \"mouafak mohamed\" du mois 09-2020','2020-10-08 01:35:55','2020-10-08 01:35:55'),(64,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 10-2020','2020-10-08 10:45:22','2020-10-08 10:45:22'),(65,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 09-2020','2020-10-08 10:52:41','2020-10-08 10:52:41'),(66,'Admin','modifier',' a modifier les informations de \"madam madam\"','2020-10-08 11:01:55','2020-10-08 11:01:55'),(67,'Admin','ajouter',' a ajouter une nouveau charge \"Assurance logement\"','2020-10-08 11:22:53','2020-10-08 11:22:53'),(68,'Admin','ajouter',' a ajouter une nouveau class pour le professeur \"khokha mouafak\"','2020-10-08 17:36:45','2020-10-08 17:36:45'),(69,'Admin','delete',' a supprimer le prof \"khokha mouafak\" de la liste des enseignants du class \"classe 2\"','2020-10-08 17:37:50','2020-10-08 17:37:50'),(70,'Admin','ajouter',' a ajouter une nouveau fichier sur le compte du professeur \"khokha mouafak\"','2020-10-08 17:43:10','2020-10-08 17:43:10'),(71,'Admin','delete',' a supprimer une fichier sur le compte de \"khokha mouafak\"','2020-10-08 17:44:51','2020-10-08 17:44:51'),(72,'Admin','ajouter',' a ajouter un nouveau visiteur \"khokha\"','2020-10-08 22:38:48','2020-10-08 22:38:48'),(73,'Admin','ajouter',' a ajouter une nouveau class pour le professeur \"khokha mouafak\"','2020-10-08 22:48:48','2020-10-08 22:48:48'),(74,'Admin','delete',' a supprimer le professeur \"khokha mouafak\"','2020-10-08 22:49:44','2020-10-08 22:49:44'),(75,'Admin','ajouter',' a ajouter des devoires pour la class \"classe 2\"','2020-10-08 22:55:58','2020-10-08 22:55:58'),(76,'Admin','modifier',' a modifier lee devoires de \"classe 2\"','2020-10-08 22:59:13','2020-10-08 22:59:13'),(77,'Admin','delete',' a supprimer une devoire ','2020-10-08 22:59:28','2020-10-08 22:59:28'),(78,'Admin','ajouter',' a ajouter un nouveau livre \"salam\"','2020-10-08 22:59:51','2020-10-08 22:59:51'),(79,'Admin','delete',' a supprimer le livre \"salam\"','2020-10-08 23:00:11','2020-10-08 23:00:11'),(80,'Admin','ajouter',' a ajouter un nouveau cour \"\"','2020-10-09 20:47:04','2020-10-09 20:47:04'),(81,'Admin','ajouter',' a ajouter une nouveau éléve \"student student\"','2020-10-11 13:10:39','2020-10-11 13:10:39'),(82,'Admin','modifier',' a modifier les informations de l\'éléve \"student student\"','2020-10-11 13:12:01','2020-10-11 13:12:01'),(83,'Admin','modifier',' a modifier les informations de l\'éléve \"student student\"','2020-10-11 13:12:08','2020-10-11 13:12:08'),(84,'Admin','ajouter',' a ajouter une nouveau éléve \"mohamed azami\"','2020-10-11 13:32:12','2020-10-11 13:32:12'),(85,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 09-2020','2020-10-11 13:33:02','2020-10-11 13:33:02'),(86,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 09-2020','2020-10-11 13:33:02','2020-10-11 13:33:02'),(87,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-11 13:42:46','2020-10-11 13:42:46'),(88,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 09-2020','2020-10-11 13:43:04','2020-10-11 13:43:04'),(89,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-11 13:44:59','2020-10-11 13:44:59'),(90,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-11 23:01:51','2020-10-11 23:01:51'),(91,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-11 23:02:40','2020-10-11 23:02:40'),(92,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-11 23:02:50','2020-10-11 23:02:50'),(93,'Admin','ajouter',' a ajouter une nouveau éléve \"khokha mouafak\"','2020-10-11 23:08:50','2020-10-11 23:08:50'),(94,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-12 13:06:24','2020-10-12 13:06:24'),(95,'Admin','ajouter',' a ajouter une nouveau class pour le professeur \"Colibri system\"','2020-10-12 15:07:50','2020-10-12 15:07:50'),(96,'Admin','modifier',' a modifier le cour \"\"','2020-10-12 16:55:49','2020-10-12 16:55:49'),(97,'Admin','ajouter',' a ajouter un nouveau livre \"salle 1\"','2020-10-12 16:57:25','2020-10-12 16:57:25'),(98,'Admin','delete',' a supprimer le livre \"salle 1\"','2020-10-12 17:11:11','2020-10-12 17:11:11'),(99,'Admin','ajouter',' a ajouter une nouveau class \"Moyyene 1\"','2020-10-12 17:11:36','2020-10-12 17:11:36'),(100,'Admin','ajouter',' a modifier les informations de la class \"Moyenne class 1\"','2020-10-12 17:11:55','2020-10-12 17:11:55'),(101,'Admin','ajouter',' a ajouter une commentaire sur le profil de l\'éléve \"student student\"','2020-10-13 01:04:41','2020-10-13 01:04:41'),(102,'Admin','ajouter',' a ajouter une commentaire sur le profil de l\'éléve \"mohamed azami\"','2020-10-13 01:06:18','2020-10-13 01:06:18'),(103,'Admin','modifier',' a modifier les informations de l\'éléve \"mohamed azami\"','2020-10-13 01:09:14','2020-10-13 01:09:14'),(104,'Admin','modifier',' a modifier les informations de l\'éléve \"mohamed azami\"','2020-10-13 01:09:28','2020-10-13 01:09:28'),(105,'Admin','delete',' a supprimer le visiteur \"\"','2020-10-14 19:10:56','2020-10-14 19:10:56'),(106,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 10-2020','2020-10-14 23:39:47','2020-10-14 23:39:47'),(107,'Admin','ajouter',' a ajouter un nouveau visiteur \"mohamed mouafak\"','2020-10-15 01:47:53','2020-10-15 01:47:53'),(108,'Admin','delete',' a supprimer le visiteur \"\"','2020-10-15 01:48:17','2020-10-15 01:48:17'),(109,'Admin','ajouter',' a ajouter un nouveau visiteur \"mohamed\"','2020-10-15 01:49:38','2020-10-15 01:49:38'),(110,'Admin','delete',' a supprimer le visiteur \"\"','2020-10-15 01:50:57','2020-10-15 01:50:57'),(111,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 09-2020','2020-10-16 12:52:00','2020-10-16 12:52:00'),(112,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 09-2020','2020-10-16 12:53:13','2020-10-16 12:53:13'),(113,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 09-2020','2020-10-16 12:55:55','2020-10-16 12:55:55'),(114,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 09-2020','2020-10-16 13:00:36','2020-10-16 13:00:36'),(115,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 09-2020','2020-10-16 13:07:31','2020-10-16 13:07:31'),(116,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 09-2020','2020-10-16 13:08:44','2020-10-16 13:08:44'),(117,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 09-2020','2020-10-16 13:17:12','2020-10-16 13:17:12'),(118,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 09-2020','2020-10-16 13:24:00','2020-10-16 13:24:00'),(119,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 09-2020','2020-10-16 14:32:30','2020-10-16 14:32:30'),(120,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 09-2020','2020-10-16 14:33:48','2020-10-16 14:33:48'),(121,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 09-2020','2020-10-16 14:37:49','2020-10-16 14:37:49'),(122,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 09-2020','2020-10-16 14:38:23','2020-10-16 14:38:23'),(123,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 09-2020','2020-10-16 14:41:18','2020-10-16 14:41:18'),(124,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 09-2020','2020-10-16 14:43:46','2020-10-16 14:43:46'),(125,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 09-2020','2020-10-16 14:44:13','2020-10-16 14:44:13'),(126,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 10-2020','2020-10-16 14:45:41','2020-10-16 14:45:41'),(127,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 10-2020','2020-10-16 14:46:08','2020-10-16 14:46:08'),(128,'Admin','ajouter',' a ajouter une nouveau produit \"type1\"','2020-10-16 16:00:52','2020-10-16 16:00:52'),(129,'Admin','modifier',' a modifier les informations de le produit \"\"','2020-10-16 16:06:38','2020-10-16 16:06:38'),(130,'Admin','ajouter',' a ajouter une nouveau produit \"type1\"','2020-10-16 16:25:13','2020-10-16 16:25:13'),(131,'Admin','modifier',' a modifier les informations de le produit \"\"','2020-10-16 16:51:01','2020-10-16 16:51:01'),(132,'Admin','modifier',' a modifier les informations de le produit \"\"','2020-10-16 16:51:10','2020-10-16 16:51:10'),(133,'Admin','modifier',' a modifier les informations de le produit \"\"','2020-10-16 16:51:19','2020-10-16 16:51:19'),(134,'Admin','modifier',' a modifier les informations de le produit \"\"','2020-10-16 16:52:01','2020-10-16 16:52:01'),(135,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 09-2020','2020-10-16 17:06:16','2020-10-16 17:06:16'),(136,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 09-2020','2020-10-16 17:09:23','2020-10-16 17:09:23'),(137,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 10-2020','2020-10-16 17:09:47','2020-10-16 17:09:47'),(138,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 09-2020','2020-10-16 17:10:34','2020-10-16 17:10:34'),(139,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 10-2020','2020-10-16 17:12:17','2020-10-16 17:12:17'),(140,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 09-2020','2020-10-16 17:19:16','2020-10-16 17:19:16'),(141,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 09-2020','2020-10-16 17:19:58','2020-10-16 17:19:58'),(142,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 10-2020','2020-10-16 17:20:17','2020-10-16 17:20:17'),(143,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 09-2020','2020-10-16 17:20:54','2020-10-16 17:20:54'),(144,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 09-2020','2020-10-16 17:21:44','2020-10-16 17:21:44'),(145,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-17 21:59:45','2020-10-17 21:59:45'),(146,'Admin','ajouter',' a ajouter un nouveau trajet \"test\"','2020-10-17 22:23:53','2020-10-17 22:23:53'),(147,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 10-2020','2020-10-18 12:06:38','2020-10-18 12:06:38'),(148,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 10-2020','2020-10-18 12:07:36','2020-10-18 12:07:36'),(149,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-18 12:09:45','2020-10-18 12:09:45'),(150,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-18 12:13:48','2020-10-18 12:13:48'),(151,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-18 12:14:16','2020-10-18 12:14:16'),(152,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-18 12:14:36','2020-10-18 12:14:36'),(153,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-18 12:15:50','2020-10-18 12:15:50'),(154,'Admin','ajouter',' a ajouter des devoires pour la class \"classe 2\"','2020-10-18 14:57:45','2020-10-18 14:57:45'),(155,'Admin','ajouter',' a ajouter des devoires pour la class \"classe 2\"','2020-10-18 15:04:27','2020-10-18 15:04:27'),(156,'Admin','ajouter',' a ajouter un nouveau cour \"\"','2020-10-19 13:56:00','2020-10-19 13:56:00'),(157,'salma salma','ajouter',' a ajouter un nouveau commentaire','2020-10-19 16:00:18','2020-10-19 16:00:18'),(158,'salma salma','ajouter',' a ajouter un nouveau commentaire','2020-10-19 16:00:31','2020-10-19 16:00:31'),(159,'salma salma','ajouter',' a ajouter un nouveau commentaire','2020-10-19 16:01:28','2020-10-19 16:01:28'),(160,'salma salma','ajouter',' a ajouter un nouveau commentaire','2020-10-19 16:01:59','2020-10-19 16:01:59'),(161,'salma salma','ajouter',' a ajouter un nouveau commentaire','2020-10-19 16:02:33','2020-10-19 16:02:33'),(162,'salma salma','ajouter',' a ajouter un nouveau commentaire','2020-10-19 16:03:24','2020-10-19 16:03:24'),(163,'salma salma','ajouter',' a ajouter un nouveau commentaire','2020-10-19 16:04:52','2020-10-19 16:04:52'),(164,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-10-20 23:38:30','2020-10-20 23:38:30'),(165,'Admin','ajouter',' a ajouter une commentaire sur le profil de l\'éléve \"salma salma\"','2020-10-21 00:43:56','2020-10-21 00:43:56'),(166,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 09-2020','2020-10-21 01:02:21','2020-10-21 01:02:21'),(167,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 10-2020','2020-10-21 01:06:55','2020-10-21 01:06:55'),(168,'Admin','ajouter',' a ajouter une nouveau charge annelle \"salam\"','2020-10-22 16:13:45','2020-10-22 16:13:45'),(169,'Admin','ajouter',' a ajouter une nouveau charge annelle \"test\"','2020-10-22 19:12:27','2020-10-22 19:12:27'),(170,'Admin','ajouter',' a ajouter une nouveau charge \"\"','2020-10-22 19:28:17','2020-10-22 19:28:17'),(171,'Admin','modifier',' a modifier la charge annuelle \"test1\"','2020-10-22 19:37:59','2020-10-22 19:37:59'),(172,'Admin','modifier',' a modifier la charge annuelle \"test1\"','2020-10-22 19:38:08','2020-10-22 19:38:08'),(173,'Admin','ajouter',' a ajouter une nouveau charge \"\"','2020-10-22 19:38:33','2020-10-22 19:38:33'),(174,'Admin','delete',' a supprimer la charge annelle \"salam\"','2020-10-22 19:41:17','2020-10-22 19:41:17'),(175,'Admin','delete',' a supprimer la charge annelle \"test1\"','2020-10-22 19:41:21','2020-10-22 19:41:21'),(176,'Admin','modifier',' a modifier la charge \"Assurance\"','2020-10-22 19:41:39','2020-10-22 19:41:39'),(177,'Admin','delete',' a supprimer la charge \"Assurance\"','2020-10-22 19:42:06','2020-10-22 19:42:06'),(178,'Admin','delete',' a supprimer la charge \"test1\"','2020-10-22 19:51:59','2020-10-22 19:51:59'),(179,'Admin','ajouter',' a ajouter une nouveau charge annelle \"colibri\"','2020-10-22 19:52:29','2020-10-22 19:52:29'),(180,'Admin','ajouter',' a ajouter une nouveau charge \"\"','2020-10-22 19:52:36','2020-10-22 19:52:36'),(181,'Admin','ajouter',' a ajouter un nouveau club \"Club théatre\"','2020-10-22 22:11:42','2020-10-22 22:11:42'),(182,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-26 16:03:10','2020-10-26 16:03:10'),(183,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-26 16:03:17','2020-10-26 16:03:17'),(184,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-26 16:03:23','2020-10-26 16:03:23'),(185,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-26 16:03:29','2020-10-26 16:03:29'),(186,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-27 13:25:11','2020-10-27 13:25:11'),(187,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-27 13:25:17','2020-10-27 13:25:17'),(188,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-27 13:25:25','2020-10-27 13:25:25'),(189,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-27 13:25:31','2020-10-27 13:25:31'),(190,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-27 13:25:37','2020-10-27 13:25:37'),(191,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-27 13:25:44','2020-10-27 13:25:44'),(192,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-27 13:25:50','2020-10-27 13:25:50'),(193,'Admin','delete',' a supprimer un champ sur l\'emploi du temp de la class \"classe 2\"','2020-10-27 13:33:07','2020-10-27 13:33:07'),(194,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-27 13:44:42','2020-10-27 13:44:42'),(195,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-28 14:06:33','2020-10-28 14:06:33'),(196,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-28 14:06:40','2020-10-28 14:06:40'),(197,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-28 14:06:49','2020-10-28 14:06:49'),(198,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-10-28 14:06:57','2020-10-28 14:06:57'),(199,'Admin','ajouter',' a ajouter une nouveau class pour le professeur \"Colibri system\"','2020-11-05 12:54:51','2020-11-05 12:54:51'),(200,'Admin','ajouter',' a ajouter une nouveau class pour le professeur \"Colibri system\"','2020-11-06 01:45:54','2020-11-06 01:45:54'),(201,'Admin','modifier',' a modifier le numéro de \"salma salma\"','2020-11-06 17:00:49','2020-11-06 17:00:49'),(202,'Admin','modifier',' a modifier le numéro de \"student student\"','2020-11-06 17:00:54','2020-11-06 17:00:54'),(203,'Admin','modifier',' a modifier le numéro de \"mohamed azami\"','2020-11-06 17:01:16','2020-11-06 17:01:16'),(204,'Admin','modifier',' a modifier le numéro de \"khokha mouafak\"','2020-11-06 17:01:23','2020-11-06 17:01:23'),(205,'Admin','modifier',' a modifier le club \"\"','2020-11-08 13:33:27','2020-11-08 13:33:27'),(206,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 10-2020','2020-11-08 13:45:55','2020-11-08 13:45:55'),(207,'Admin','frai',' a valider le paiement de l\'éléve \"salma salma\" du mois 11-2020','2020-11-08 13:46:03','2020-11-08 13:46:03'),(208,'Admin','ajouter',' a ajouter une commentaire sur le profil de l\'éléve \"salma salma\"','2020-11-08 18:23:34','2020-11-08 18:23:34'),(209,'Parents','ajouter',' a ajouter une commentaire sur le profil de l\'éléve \"salma salma\"','2020-11-09 01:35:50','2020-11-09 01:35:50'),(210,'Parents','ajouter',' a ajouter une commentaire sur le profil de l\'éléve \"salma salma\"','2020-11-09 01:44:29','2020-11-09 01:44:29'),(211,'Admin','delete',' a supprimer le prof \"Colibri system\" de la liste des enseignants du class \"classe 1\"','2020-11-09 13:41:49','2020-11-09 13:41:49'),(212,'Admin','delete',' a supprimer un champ sur l\'emploi du temp de la class \"classe 2\"','2020-11-09 16:09:25','2020-11-09 16:09:25'),(213,'Admin','delete',' a supprimer un champ sur l\'emploi du temp de la class \"classe 2\"','2020-11-09 16:09:31','2020-11-09 16:09:31'),(214,'Admin','delete',' a supprimer un champ sur l\'emploi du temp de la class \"classe 2\"','2020-11-09 17:11:59','2020-11-09 17:11:59'),(215,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-09 17:12:06','2020-11-09 17:12:06'),(216,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-09 17:12:27','2020-11-09 17:12:27'),(217,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-09 17:12:40','2020-11-09 17:12:40'),(218,'Admin','delete',' a supprimer un champ sur l\'emploi du temp de la class \"classe 2\"','2020-11-09 17:12:55','2020-11-09 17:12:55'),(219,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-09 17:21:54','2020-11-09 17:21:54'),(220,'Admin','delete',' a supprimer un champ sur l\'emploi du temp de la class \"classe 2\"','2020-11-09 20:17:54','2020-11-09 20:17:54'),(221,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-09 20:17:59','2020-11-09 20:17:59'),(222,'Admin','delete',' a supprimer un champ sur l\'emploi du temp de la class \"classe 2\"','2020-11-09 20:18:12','2020-11-09 20:18:12'),(223,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-09 20:18:23','2020-11-09 20:18:23'),(224,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-09 21:11:42','2020-11-09 21:11:42'),(225,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-09 21:11:52','2020-11-09 21:11:52'),(226,'Admin','ajouter',' a ajouter une nouveau matiere \"Francais\"','2020-11-09 21:12:38','2020-11-09 21:12:38'),(227,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-09 21:28:12','2020-11-09 21:28:12'),(228,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-09 21:28:19','2020-11-09 21:28:19'),(229,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 13:28:15','2020-11-10 13:28:15'),(230,'Admin','delete',' a supprimer un champ sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 13:28:22','2020-11-10 13:28:22'),(231,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 13:28:28','2020-11-10 13:28:28'),(232,'Admin','modifier',' a modifier l\'emploi du temp de la class \"classe 2\"','2020-11-10 14:56:09','2020-11-10 14:56:09'),(233,'Admin','modifier',' a modifier l\'emploi du temp de la class \"classe 2\"','2020-11-10 14:56:15','2020-11-10 14:56:15'),(234,'Admin','modifier',' a modifier l\'emploi du temp de la class \"classe 2\"','2020-11-10 14:56:24','2020-11-10 14:56:24'),(235,'Admin','delete',' a supprimer un champ sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 14:56:38','2020-11-10 14:56:38'),(236,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 17:05:08','2020-11-10 17:05:08'),(237,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 17:05:14','2020-11-10 17:05:14'),(238,'Admin','ajouter',' a ajouter une nouveau class pour le professeur \"Colibri system\"','2020-11-10 17:17:27','2020-11-10 17:17:27'),(239,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 21:19:08','2020-11-10 21:19:08'),(240,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 21:19:14','2020-11-10 21:19:14'),(241,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 21:19:20','2020-11-10 21:19:20'),(242,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:20:53','2020-11-10 23:20:53'),(243,'Admin','delete',' a supprimer un champ sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:25:23','2020-11-10 23:25:23'),(244,'Admin','delete',' a supprimer un champ sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:25:30','2020-11-10 23:25:30'),(245,'Admin','delete',' a supprimer un champ sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:25:34','2020-11-10 23:25:34'),(246,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:25:45','2020-11-10 23:25:45'),(247,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:25:53','2020-11-10 23:25:53'),(248,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:26:02','2020-11-10 23:26:02'),(249,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:26:15','2020-11-10 23:26:15'),(250,'Admin','modifier',' a modifier l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:26:47','2020-11-10 23:26:47'),(251,'Admin','delete',' a supprimer un champ sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:28:48','2020-11-10 23:28:48'),(252,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:52:11','2020-11-10 23:52:11'),(253,'Admin','delete',' a supprimer un champ sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:52:41','2020-11-10 23:52:41'),(254,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:55:54','2020-11-10 23:55:54'),(255,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:56:05','2020-11-10 23:56:05'),(256,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:56:11','2020-11-10 23:56:11'),(257,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:56:17','2020-11-10 23:56:17'),(258,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:56:50','2020-11-10 23:56:50'),(259,'Admin','delete',' a supprimer un champ sur l\'emploi du temp de la class \"classe 2\"','2020-11-10 23:57:01','2020-11-10 23:57:01'),(260,'Admin','ajouter',' a ajouter un nouveau cour sur l\'emploi du temp de la class \"classe 1\"','2020-11-11 15:32:25','2020-11-11 15:32:25'),(261,'Admin','ajouter',' a ajouter une nouveau éléve \"islam islam\"','2020-11-12 18:01:56','2020-11-12 18:01:56'),(262,'Admin','modifier',' a modifier les informations de l\'éléve \"mohamed azami\"','2020-11-12 18:45:43','2020-11-12 18:45:43'),(263,'Admin','modifier',' a modifier les informations de l\'éléve \"islam islam\"','2020-11-12 19:18:40','2020-11-12 19:18:40'),(264,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-11-12 19:19:00','2020-11-12 19:19:00'),(265,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-11-12 19:43:29','2020-11-12 19:43:29'),(266,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-11-12 19:51:50','2020-11-12 19:51:50'),(267,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-11-12 19:52:48','2020-11-12 19:52:48'),(268,'Admin','modifier',' a modifier les informations de l\'éléve \"student student\"','2020-11-16 15:57:54','2020-11-16 15:57:54'),(269,'Admin','modifier',' a modifier les informations de l\'éléve \"student student\"','2020-11-16 15:58:42','2020-11-16 15:58:42'),(270,'Admin','modifier',' a modifier les informations de l\'éléve \"mohamed azami\"','2020-11-16 16:39:50','2020-11-16 16:39:50'),(271,'Admin','modifier',' a modifier les informations de l\'éléve \"mohamed azami\"','2020-11-16 16:42:14','2020-11-16 16:42:14'),(272,'Admin','modifier',' a modifier les informations de l\'éléve \"mohamed azami\"','2020-11-16 16:42:34','2020-11-16 16:42:34'),(273,'Admin','modifier',' a modifier les informations de l\'éléve \"mohamed azami\"','2020-11-16 16:43:16','2020-11-16 16:43:16'),(274,'Admin','modifier',' a modifier les informations de l\'éléve \"student student\"','2020-11-16 17:46:36','2020-11-16 17:46:36'),(275,'Admin','modifier',' a modifier les informations de l\'éléve \"student student\"','2020-11-16 17:48:16','2020-11-16 17:48:16'),(276,'Admin','modifier',' a modifier les informations de l\'éléve \"student student\"','2020-11-16 17:49:05','2020-11-16 17:49:05'),(277,'Admin','modifier',' a modifier les informations de l\'éléve \"mohamed azami\"','2020-11-16 17:50:43','2020-11-16 17:50:43'),(278,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 09-2020','2020-11-16 17:51:05','2020-11-16 17:51:05'),(279,'Admin','frai',' a valider le paiement de l\'éléve \"mohamed azami\" du mois 10-2020','2020-11-16 17:51:11','2020-11-16 17:51:11'),(280,'Admin','valider',' a valider le réinscription de l\'éléve \"student student\"','2020-11-17 21:34:08','2020-11-17 21:34:08'),(281,'Admin','valider',' a valider le réinscription de l\'éléve \"mohamed azami\"','2020-11-17 21:40:28','2020-11-17 21:40:28'),(282,'Admin','modifier',' a modifier les informations de l\'éléve \"mohamed azami\"','2020-11-17 21:51:07','2020-11-17 21:51:07'),(283,'Admin','valider',' a valider le réinscription de l\'éléve \"salma salma\"','2020-11-17 21:59:40','2020-11-17 21:59:40'),(284,'Admin','ajouter',' a ajouter une nouveau éléve \"ostad ostad\"','2020-11-18 11:32:07','2020-11-18 11:32:07'),(285,'Admin','ajouter',' a ajouter une nouveau éléve \"ahlan ostad\"','2020-11-18 11:34:16','2020-11-18 11:34:16'),(286,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-11-19 20:24:18','2020-11-19 20:24:18'),(287,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-11-19 20:24:55','2020-11-19 20:24:55'),(288,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-11-19 20:25:11','2020-11-19 20:25:11'),(289,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-11-19 20:26:16','2020-11-19 20:26:16'),(290,'Admin','modifier',' a modifier les informations de l\'éléve \"salma salma\"','2020-11-19 20:26:39','2020-11-19 20:26:39');
/*!40000 ALTER TABLE `tracabilites` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trajets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `transport` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `trajets` DISABLE KEYS */;
INSERT INTO `trajets` (`id`, `name`, `transport`, `created_at`, `updated_at`) VALUES (1,'test',1,'2020-10-17 22:23:53','2020-10-17 22:23:53');
/*!40000 ALTER TABLE `trajets` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `A` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `B` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `C` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `marque` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `accom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `choffeur` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note` text COLLATE utf8_unicode_ci NOT NULL,
  `num` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `transports` DISABLE KEYS */;
INSERT INTO `transports` (`id`, `name`, `A`, `B`, `C`, `marque`, `model`, `accom`, `choffeur`, `note`, `num`, `id1`, `created_at`, `updated_at`) VALUES (1,'trans 1','121212','ب','12','fiat','ducato','20','19','walo','121212 ب 12','VH121212','2020-10-07 22:33:32','2020-10-07 22:33:32');
/*!40000 ALTER TABLE `transports` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tele` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fix` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ville` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `nom`, `logo`, `tele`, `fix`, `ville`, `adress`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES (2,'Group Scolaire Mohammed V','images/users/1602098427jpg','0606060606','0505050505','test@001.ma','115 alot 3 rout meknes wed fes fes','test@001.ma',NULL,'$2y$10$4zJBpRPkoGYA1EG/U.4D8uvJ/j69zYMwsxKXHO0D6Wi6URY43MVT.',NULL,'2020-10-07 19:20:28','2020-11-11 17:13:09');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visiters` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `objectif` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tele` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cin` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `time1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `time2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `visiters` DISABLE KEYS */;
/*!40000 ALTER TABLE `visiters` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

